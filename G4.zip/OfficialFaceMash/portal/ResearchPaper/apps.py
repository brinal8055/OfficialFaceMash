from django.apps import AppConfig


class ResearchpaperConfig(AppConfig):
    name = 'ResearchPaper'
